package sockethw1;

import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * TCPServerQuiz is a multi-threaded TCP server that administers a simple quiz to connected clients.
 * Each client receives a series of quiz questions, submits answers, and receives feedback.
 * The server handles multiple clients concurrently using a thread pool.
 */
public class TCPServerQuiz {
    // Port number for the server to listen on
    private static int port = 1234;

    // Array of quiz questions and answers
    private static final String[][] QUIZ = {
        {"What is the macbook of company?", "apple"},
        {"What is 5 + 7?", "12"},
        {"What is 3*4?", "12"}
    };

    /**
     * The main method starts the server, loads the configuration,
     * initializes the server socket and thread pool, and waits for client connections.
     *
     * @param args Command-line arguments (not used)
     * @throws IOException If an I/O error occurs when opening the socket
     */
    public static void main(String[] args) throws IOException {
        loadServerConfig();  // Load server configuration from file if available

        ServerSocket serverSocket = new ServerSocket(port);  // Create a server socket on the specified port
        ExecutorService threadPool = Executors.newFixedThreadPool(4); // Fixed thread pool to handle multiple clients
        System.out.println("Quiz Server started on port " + port);

        // Infinite loop to accept and handle incoming client connections
        while (true) {
            Socket clientSocket = serverSocket.accept();  // Accept an incoming client connection
            threadPool.execute(new ClientHandler(clientSocket));  // Create a new ClientHandler to handle the client
        }
    }

    /**
     * Loads the server's port number from a configuration file ("server_info.dat").
     * If the file is missing or invalid, the server uses the default port 1234.
     */
    private static void loadServerConfig() {
        File configFile = new File("server_info.dat");
        if (configFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(configFile))) {
                port = Integer.parseInt(reader.readLine());  // Read and set the port number
            } catch (IOException | NumberFormatException e) {
                System.out.println("Invalid config file. Using default port.");
            }
        } else {
            System.out.println("Config file not found. Using default port.");
        }
    }

    /**
     * ClientHandler is a Runnable class that handles the quiz session for a single client.
     * It sends questions, receives answers, provides feedback, and calculates the final score.
     */
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;  // Socket for client-server communication

        /**
         * Constructor to initialize ClientHandler with the client's socket.
         *
         * @param socket The socket connected to the client
         */
        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        /**
         * The run method executes the quiz session for the client.
         * Sends each question, receives the client's answer, sends feedback,
         * and finally sends the score to the client.
         */
        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); // Input stream to receive data from client
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream()) // Output stream to send data to client
            ) {
                int score = 0;  // Variable to keep track of the client's score

                // Loop through each quiz question
                for (String[] question : QUIZ) {
                    out.writeBytes("QUESTION:" + question[0] + '\n');  // Send the question to the client
                    String answer = in.readLine();  // Read the client's answer

                    // Check if the client's answer is correct
                    if (answer != null && answer.equalsIgnoreCase(question[1])) {
                        out.writeBytes("FEEDBACK:Correct\n");  // Send feedback if correct
                        score++;  // Increase score for a correct answer
                    } else {
                        out.writeBytes("FEEDBACK:Incorrect\n");  // Send feedback if incorrect
                    }
                }

                // Send the final score to the client after all questions
                out.writeBytes("SCORE:" + score + "/" + QUIZ.length + "\n");
            } catch (IOException e) {
                e.printStackTrace();  // Print stack trace if an I/O error occurs
            }
        }
    }
}
