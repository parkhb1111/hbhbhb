package sockethw1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

/**
 * TCPClientQuiz is a TCP client application that connects to a quiz server,
 * receives questions, sends answers, and displays feedback and the final score
 * in a graphical user interface (GUI).
 */
public class TCPClientQuiz {
    // Default IP address and port for the quiz server
    private static String serverIP = "127.0.0.1";  // Server IP address (default is localhost)
    private static int port = 1234;                // Server port number (default is 1234)

    // Network communication components
    private static Socket clientSocket;            // Client socket, represents the connection to the server
    private static BufferedReader in;              // Input stream to read data from the server
    private static DataOutputStream out;           // Output stream to send data to the server

    // GUI components
    private static JFrame frame;                   // Main frame (window)
    private static JLabel questionLabel;           // Label to display quiz questions
    private static JTextField answerField;         // Text field for user to input their answer
    private static JTextArea resultArea;           // Text area to display feedback and final score
    private static JButton sendButton;             // Button to send the answer

    /**
     * Main method to start the client application.
     * 1. Loads server configuration.
     * 2. Establishes connection with the server.
     * 3. Sets up the GUI.
     * 4. Loads the first question from the server.
     *
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        loadServerConfig();      // Load server configuration
        setupConnection();       // Set up the connection to the server
        setupGUI();              // Set up the GUI
        loadNextQuestion();      // Load the first question from the server
    }

    /**
     * Loads the server IP address and port from a configuration file ("server_info.dat").
     * If the file is missing or invalid, defaults to "localhost" and port 1234.
     */
    private static void loadServerConfig() {
        File configFile = new File("server_info.dat");
        if (configFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(configFile))) {
                serverIP = reader.readLine();              // Read the IP address
                port = Integer.parseInt(reader.readLine()); // Read the port number
            } catch (IOException | NumberFormatException e) {
                System.out.println("Invalid config file. Using default server settings.");
            }
        } else {
            System.out.println("Config file not found. Using default server settings.");
        }
    }

    /**
     * Sets up the connection to the server using the specified IP address and port.
     * Initializes input and output streams for communication.
     */
    private static void setupConnection() {
        try {
            clientSocket = new Socket(serverIP, port);           // Connect to the server
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); // Input stream to receive data
            out = new DataOutputStream(clientSocket.getOutputStream());                   // Output stream to send data
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets up the graphical user interface (GUI) for the quiz application.
     * The GUI includes a label for the question, a text field for the answer,
     * a text area for displaying results, and a button to submit the answer.
     */
    private static void setupGUI() {
        frame = new JFrame("Quiz Game");                  // Create the main application window
        frame.setSize(500, 400);                          // Set the window size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the application on window close

        questionLabel = new JLabel("Question will appear here");  // Label to display questions
        answerField = new JTextField(20);                         // Text field for answer input
        resultArea = new JTextArea(10, 30);                       // Text area for feedback and score
        resultArea.setEditable(false);                            // Make the text area read-only
        sendButton = new JButton("Send Answer");                  // Button to submit answer

        sendButton.addActionListener(new ActionListener() {       // Action listener for button click
            @Override
            public void actionPerformed(ActionEvent e) {
                sendAnswer();                                     // Call sendAnswer() when clicked
            }
        });

        frame.setLayout(new FlowLayout());                        // Set layout for the frame
        frame.add(questionLabel);                                 // Add question label to the frame
        frame.add(answerField);                                   // Add answer field to the frame
        frame.add(sendButton);                                    // Add send button to the frame
        frame.add(new JScrollPane(resultArea));                   // Add scrollable text area for results

        frame.setVisible(true);                                   // Make the GUI visible
    }

    /**
     * Reads the next question from the server and updates the question label in the GUI.
     * If the server sends the final score, it displays the score and disables input.
     */
    private static void loadNextQuestion() {
        try {
            String questionMessage = in.readLine();           // Read message from the server
            if (questionMessage != null && questionMessage.startsWith("QUESTION:")) {
                String question = questionMessage.substring(9);  // Extract the question text
                questionLabel.setText(question);                 // Display the question in the GUI
            } else if (questionMessage != null && questionMessage.startsWith("SCORE:")) {
                String scoreText = questionMessage.substring(6); // Extract the score text
                resultArea.append("Final Score: " + scoreText + "\n"); // Display final score
                sendButton.setEnabled(false);                    // Disable the send button
                answerField.setEnabled(false);                   // Disable the answer field
                closeConnection();                               // Close the connection after final score
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sends the user's answer to the server and processes the feedback.
     * Displays whether the answer was correct or incorrect and loads the next question.
     * If the server sends the final score, it displays the score and disables input.
     */
    private static void sendAnswer() {
        try {
            String answer = answerField.getText();              // Get the user's answer from the text field
            out.writeBytes(answer + "\n");                      // Send the answer to the server
            String feedback = in.readLine();                    // Read feedback from the server

            if (feedback != null && feedback.startsWith("FEEDBACK:")) {
                String feedbackText = feedback.substring(9);    // Extract feedback text
                resultArea.append("Your answer is " + feedbackText + "\n"); // Display feedback
                answerField.setText("");                        // Clear the answer field
                loadNextQuestion();                             // Load the next question
            } else if (feedback != null && feedback.startsWith("SCORE:")) {
                String scoreText = feedback.substring(6);       // Extract the score text
                resultArea.append("Final Score: " + scoreText + "\n"); // Display final score
                sendButton.setEnabled(false);                   // Disable the send button
                answerField.setEnabled(false);                  // Disable the answer field
                closeConnection();                              // Close the connection after final score
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Closes the connection to the server by closing the client socket.
     * Displays a message in the result area indicating that the connection has been closed.
     */
    private static void closeConnection() {
        try {
            if (clientSocket != null && !clientSocket.isClosed()) {
                clientSocket.close();                           // Close the client socket
                resultArea.append("Connection closed.\n");      // Notify user that the connection is closed
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
